from datetime import date, datetime
from html import escape

import streamlit as st
from sqlalchemy import select

from comparables import (
    buscar_comparables,
    calcular_score_variable,
    calcular_tasacion_comparables,
    filtrar_outliers_iqr,
    obtener_precio_clp,
)
from database import SessionLocal, init_db
from main import calcular_tasacion
from models import Listing, PriceHistory, Property


COMUNA_COORDENADAS = {
    "Ñuñoa": (-33.456, -70.597),
    "Providencia": (-33.426, -70.617),
    "Las Condes": (-33.408, -70.567),
    "Santiago": (-33.448, -70.669),
    "Vitacura": (-33.386, -70.573),
    "La Reina": (-33.441, -70.535),
    "Macul": (-33.487, -70.599),
    "La Florida": (-33.522, -70.598),
    "San Miguel": (-33.496, -70.651),
    "Recoleta": (-33.406, -70.642),
    "Independencia": (-33.414, -70.665),
    "Peñalolén": (-33.486, -70.533),
    "Puente Alto": (-33.616, -70.575),
}


def geocode_simple(comuna, direccion=None):
    return COMUNA_COORDENADAS.get(comuna, (None, None))


def get_or_create_property(db, property_data):
    statement = select(Property).filter_by(**property_data)
    property_record = db.execute(statement).scalar_one_or_none()

    if property_record is not None:
        return property_record

    property_record = Property(**property_data)
    db.add(property_record)
    db.flush()
    return property_record


def save_listing(property_data, precio_clp):
    with SessionLocal() as db:
        property_record = get_or_create_property(db, property_data)
        listing = Listing(
            property_id=property_record.id,
            fuente="tasador_app",
            source_listing_id=None,
            url=None,
            status="appraisal_result",
            precio_clp=precio_clp,
            precio_uf=None,
            comuna=property_data["comuna"],
            lat=property_data.get("lat"),
            lon=property_data.get("lon"),
            m2_construidos=property_data["m2_construidos"],
            m2_terreno=property_data["m2_terreno"],
            m2_util=None,
            m2_total=property_data["m2_terreno"],
            dormitorios=property_data["dormitorios"],
            banos=property_data["banos"],
            estacionamientos=property_data["estacionamientos"],
            fecha_publicacion=None,
            fecha_captura=date.today(),
        )
        db.add(listing)
        db.flush()
        db.add(
            PriceHistory(
                listing_id=listing.id,
                precio_clp=precio_clp,
                precio_uf=None,
                precio_clp_anterior=None,
                precio_uf_anterior=None,
                precio_clp_nuevo=precio_clp,
                precio_uf_nuevo=None,
                fecha_captura=listing.fecha_captura,
                fecha_cambio=datetime.now(),
            )
        )
        db.commit()
        db.refresh(property_record)
        db.refresh(listing)
        return property_record.id, listing.id


def format_clp(value):
    if value is None:
        return "Sin precio"

    return f"${value:,.0f}".replace(",", ".")


def preparar_comparables_usados(property_data, comparables):
    comparables_validos = []

    for comparable in comparables:
        precio_clp = obtener_precio_clp(comparable)
        comparable_m2 = comparable.m2_construidos

        if precio_clp is None:
            continue

        if not comparable_m2 or comparable_m2 <= 0:
            continue

        score_m2 = calcular_score_variable(
            property_data["m2_construidos"],
            comparable_m2,
        )
        score_dormitorios = calcular_score_variable(
            property_data["dormitorios"],
            comparable.dormitorios,
        )
        score_banos = calcular_score_variable(
            property_data["banos"],
            comparable.banos,
        )
        score_estacionamientos = calcular_score_variable(
            property_data["estacionamientos"],
            comparable.estacionamientos,
        )
        score = (
            score_m2 * 0.4
            + score_dormitorios * 0.2
            + score_banos * 0.2
            + score_estacionamientos * 0.2
        )

        if score <= 0:
            continue

        comparables_validos.append(
            {
                "listing": comparable,
                "precio_clp": precio_clp,
                "precio_m2": precio_clp / comparable_m2,
                "score": score,
            }
        )

    return filtrar_outliers_iqr(comparables_validos)


def calcular_precio_promedio_m2(comparables_usados):
    if not comparables_usados:
        return None

    precios_m2 = [comparable["precio_m2"] for comparable in comparables_usados]
    return sum(precios_m2) / len(precios_m2)


def calcular_superficie_promedio(comparables_usados):
    superficies = [
        comparable["listing"].m2_construidos
        for comparable in comparables_usados
        if comparable["listing"].m2_construidos
    ]

    if not superficies:
        return None

    return sum(superficies) / len(superficies)


def calcular_desviacion_estimada(comparables_usados):
    precios_m2 = [comparable["precio_m2"] for comparable in comparables_usados]

    if len(precios_m2) < 2:
        return None

    promedio = sum(precios_m2) / len(precios_m2)

    if promedio <= 0:
        return None

    varianza = sum((precio_m2 - promedio) ** 2 for precio_m2 in precios_m2) / len(
        precios_m2
    )
    desviacion = varianza ** 0.5
    return desviacion / promedio


def calcular_promedio_atributo(comparables_usados, atributo):
    valores = [
        getattr(comparable["listing"], atributo)
        for comparable in comparables_usados
        if getattr(comparable["listing"], atributo) is not None
    ]

    if not valores:
        return None

    return sum(valores) / len(valores)


def limitar_impacto(value, minimo=-0.12, maximo=0.12):
    return max(min(value, maximo), minimo)


def calcular_factores_tasacion(property_data, comparables_usados):
    superficie_promedio = calcular_superficie_promedio(comparables_usados)
    dormitorios_promedio = calcular_promedio_atributo(comparables_usados, "dormitorios")
    ano_actual = date.today().year
    antiguedad = ano_actual - property_data["ano_construccion"]

    if superficie_promedio:
        impacto_superficie = limitar_impacto(
            ((property_data["m2_construidos"] / superficie_promedio) - 1) * 0.35
        )
    else:
        impacto_superficie = 0

    if len(comparables_usados) >= 5:
        impacto_ubicacion = 0.08
    elif comparables_usados:
        impacto_ubicacion = 0.03
    else:
        impacto_ubicacion = -0.05

    if dormitorios_promedio:
        impacto_dormitorios = limitar_impacto(
            (property_data["dormitorios"] - dormitorios_promedio) * 0.03
        )
    else:
        impacto_dormitorios = 0

    if antiguedad <= 5:
        impacto_antiguedad = 0.06
    elif antiguedad <= 15:
        impacto_antiguedad = 0.02
    elif antiguedad <= 30:
        impacto_antiguedad = -0.03
    else:
        impacto_antiguedad = -0.08

    return [
        {
            "nombre": "Superficie",
            "impacto": impacto_superficie,
            "detalle": "Comparada con propiedades similares.",
        },
        {
            "nombre": "Ubicación",
            "impacto": impacto_ubicacion,
            "detalle": f"Basado en comparables disponibles en {property_data['comuna']}.",
        },
        {
            "nombre": "Dormitorios",
            "impacto": impacto_dormitorios,
            "detalle": "Ajuste frente al promedio de comparables.",
        },
        {
            "nombre": "Antigüedad",
            "impacto": impacto_antiguedad,
            "detalle": f"Propiedad con {max(antiguedad, 0)} años aproximados.",
        },
    ]


def format_m2(value):
    if value is None:
        return "Sin datos"

    return f"{value:,.0f} m²".replace(",", ".")


def format_percent(value):
    if value is None:
        return "Sin datos"

    return f"±{value * 100:.1f}%"


def format_impact(value):
    sign = "+" if value >= 0 else ""
    return f"{sign}{value * 100:.0f}%"


def interpretar_resultado(precio_resultado_m2, precio_promedio_m2):
    if not precio_promedio_m2 or precio_promedio_m2 <= 0:
        return {
            "estado": "En mercado",
            "clase": "neutral",
            "descripcion": "No hay suficientes comparables para clasificar el valor con mayor precisión.",
        }

    diferencia = (precio_resultado_m2 / precio_promedio_m2) - 1

    if diferencia < -0.08:
        return {
            "estado": "Bajo mercado",
            "clase": "low",
            "descripcion": "El valor estimado está por debajo del promedio observado en propiedades similares.",
        }

    if diferencia > 0.08:
        return {
            "estado": "Sobre mercado",
            "clase": "high",
            "descripcion": "El valor estimado está por encima del promedio de los comparables disponibles.",
        }

    return {
        "estado": "En mercado",
        "clase": "neutral",
        "descripcion": "El valor estimado se encuentra dentro del rango esperado para comparables similares.",
    }


def mostrar_interpretacion_resultado(interpretacion):
    st.markdown(
        f"""
        <div class="interpretation-card interpretation-inline {interpretacion["clase"]}">
            <div class="interpretation-copy">{interpretacion["descripcion"]}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def generar_resumen_automatico(interpretacion, factores_tasacion):
    factores_ordenados = sorted(
        factores_tasacion,
        key=lambda factor: abs(factor["impacto"]),
        reverse=True,
    )
    factores_principales = [factor["nombre"].lower() for factor in factores_ordenados[:2]]

    if len(factores_principales) == 2:
        factores_texto = f"{factores_principales[0]} y {factores_principales[1]}"
    elif factores_principales:
        factores_texto = factores_principales[0]
    else:
        factores_texto = "los comparables disponibles"

    return (
        f"La propiedad se encuentra {interpretacion['estado'].lower()} según los comparables disponibles. "
        f"Los factores que más influyen en esta estimación son {factores_texto}. "
        "La lectura combina precio por m², similitud y consistencia de mercado."
    )


def mostrar_resumen_automatico(resumen):
    st.markdown(
        f"""
        <div class="auto-summary auto-summary-inline">
            <div class="auto-summary-title">Resumen automático</div>
            <div class="auto-summary-copy">{resumen}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def mostrar_metric_card(titulo, valor, descripcion="", icono=""):
    titulo_completo = f"{icono} {titulo}" if icono else titulo
    descripcion_html = (
        f'<div class="key-metric-copy">{descripcion}</div>' if descripcion else ""
    )
    st.markdown(
        f"""
        <div class="key-metric-card">
            <div class="key-metric-value">{valor}</div>
            <div class="key-metric-title">{titulo_completo}</div>
            {descripcion_html}
        </div>
        """,
        unsafe_allow_html=True,
    )


def obtener_tipologia_dominante(comparables_usados):
    conteos = {}

    for comparable_data in comparables_usados:
        comparable = comparable_data["listing"]

        if comparable.dormitorios is None and comparable.banos is None:
            continue

        dormitorios = comparable.dormitorios if comparable.dormitorios is not None else "sin dato"
        banos = comparable.banos if comparable.banos is not None else "sin dato"
        tipologia = f"{dormitorios} dorm / {banos} baños"
        conteos[tipologia] = conteos.get(tipologia, 0) + 1

    if not conteos:
        return "Sin datos"

    return max(conteos.items(), key=lambda item: item[1])[0]


def mostrar_resumen_comparables(comparables_usados):
    superficies = [
        comparable_data["listing"].m2_construidos
        for comparable_data in comparables_usados
        if comparable_data["listing"].m2_construidos
        and comparable_data["listing"].m2_construidos > 0
    ]
    precios = [
        comparable_data["precio_clp"]
        for comparable_data in comparables_usados
        if comparable_data["precio_clp"] and comparable_data["precio_clp"] > 0
    ]

    cantidad = len(comparables_usados)
    rango_superficie = (
        f"{format_m2(min(superficies))} - {format_m2(max(superficies))}"
        if superficies
        else "Sin datos"
    )
    rango_precios = (
        f"{format_clp(min(precios))} - {format_clp(max(precios))}"
        if precios
        else "Sin datos"
    )
    tipologia = obtener_tipologia_dominante(comparables_usados)

    st.markdown(
        f"""
        <div class="comparables-summary">
            <div class="comparables-summary-header">
                <div>
                    <div class="section-title">Resumen de comparables</div>
                    <div class="section-copy">Vista simplificada de la muestra usada para sostener el cálculo.</div>
                </div>
                <span class="summary-status">Visualización simple</span>
            </div>
            <div class="comparables-summary-grid">
                <div class="summary-item">
                    <div class="summary-label">Comparables analizados</div>
                    <div class="summary-value">{escape(str(cantidad))}</div>
                </div>
                <div class="summary-item">
                    <div class="summary-label">Rango de superficie</div>
                    <div class="summary-value">{escape(rango_superficie)}</div>
                </div>
                <div class="summary-item">
                    <div class="summary-label">Rango de precios</div>
                    <div class="summary-value">{escape(rango_precios)}</div>
                </div>
                <div class="summary-item">
                    <div class="summary-label">Tipología dominante</div>
                    <div class="summary-value">{escape(tipologia)}</div>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def format_clp_corto(value):
    if value is None:
        return "Sin precio"

    if value >= 1_000_000:
        return f"${value / 1_000_000:.0f} MM"

    return format_clp(value)


def scale_value(value, min_value, max_value, min_position, max_position):
    if max_value == min_value:
        return (min_position + max_position) / 2

    ratio = (value - min_value) / (max_value - min_value)
    return min_position + ratio * (max_position - min_position)


def mostrar_grafico_posicion(property_data, valor, comparables_usados):
    puntos = []

    for comparable_data in comparables_usados:
        comparable = comparable_data["listing"]

        if not comparable.m2_construidos or comparable.m2_construidos <= 0:
            continue

        puntos.append(
            {
                "m2": comparable.m2_construidos,
                "precio": comparable_data["precio_clp"],
                "score": comparable_data["score"],
            }
        )

    puntos.append(
        {
            "m2": property_data["m2_construidos"],
            "precio": valor,
            "score": 1,
            "target": True,
        }
    )

    if len(puntos) < 2:
        st.info("No hay suficientes datos para graficar el posicionamiento.")
        return

    min_m2 = min(punto["m2"] for punto in puntos)
    max_m2 = max(punto["m2"] for punto in puntos)
    min_precio = min(punto["precio"] for punto in puntos)
    max_precio = max(punto["precio"] for punto in puntos)
    width = 680
    height = 320
    left = 56
    right = 28
    top = 28
    bottom = 52
    plot_width = width - left - right
    plot_height = height - top - bottom
    circles = []

    for punto in puntos:
        x = scale_value(punto["m2"], min_m2, max_m2, left, left + plot_width)
        y = scale_value(
            punto["precio"],
            min_precio,
            max_precio,
            top + plot_height,
            top,
        )

        if punto.get("target"):
            circles.append(
                f"""
                <circle cx="{x:.1f}" cy="{y:.1f}" r="9" class="scatter-target" />
                <text x="{x + 13:.1f}" y="{y - 10:.1f}" class="scatter-label">Propiedad</text>
                """
            )
        else:
            radius = 4 + min(punto["score"], 1) * 3
            circles.append(
                f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{radius:.1f}" class="scatter-point" />'
            )

    st.markdown(
        f"""
        <div class="scatter-card">
            <div class="scatter-header">
                <div>
                    <div class="section-title">Posición frente al mercado</div>
                    <div class="section-copy">Superficie versus precio de comparables.</div>
                </div>
                <div class="scatter-legend">
                    <span><i class="legend-dot market"></i> Comparables</span>
                    <span><i class="legend-dot target"></i> Propiedad</span>
                </div>
            </div>
            <svg viewBox="0 0 {width} {height}" class="scatter-svg" role="img">
                <line x1="{left}" y1="{top}" x2="{left}" y2="{top + plot_height}" class="axis-line" />
                <line x1="{left}" y1="{top + plot_height}" x2="{left + plot_width}" y2="{top + plot_height}" class="axis-line" />
                <text x="{left}" y="{height - 18}" class="axis-label">{format_m2(min_m2)}</text>
                <text x="{left + plot_width - 46}" y="{height - 18}" class="axis-label">{format_m2(max_m2)}</text>
                <text x="8" y="{top + plot_height}" class="axis-label">{format_clp_corto(min_precio)}</text>
                <text x="8" y="{top + 6}" class="axis-label">{format_clp_corto(max_precio)}</text>
                {"".join(circles)}
            </svg>
        </div>
        """,
        unsafe_allow_html=True,
    )


def mostrar_factor_tasacion(factor):
    impacto = factor["impacto"]
    bar_width = min(abs(impacto) / 0.12 * 100, 100)
    bar_class = "positive" if impacto >= 0 else "negative"

    st.markdown(
        f"""
        <div class="factor-row">
            <div class="factor-name">{factor["nombre"]}</div>
            <div class="factor-track">
                <div class="factor-bar {bar_class}" style="width: {bar_width}%;"></div>
            </div>
            <div class="factor-impact {bar_class}">{format_impact(impacto)}</div>
            <div class="factor-detail">
                {factor["detalle"]}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def calcular_distancia_texto(comparable):
    if comparable.lat is None or comparable.lon is None:
        return "Sin dato"

    return "Ubicación disponible"


def calcular_similitud_visual(score):
    if score >= 0.85:
        return "alta"

    if score >= 0.65:
        return "media"

    return "baja"


def mostrar_tabla_comparables(comparables_usados):
    filas = []

    for ranking, comparable_data in enumerate(
        sorted(
            comparables_usados,
            key=lambda item: item["score"],
            reverse=True,
        ),
        start=1,
    ):
        comparable = comparable_data["listing"]
        similitud = calcular_similitud_visual(comparable_data["score"])
        filas.append(
            {
                "titulo": f"Comparable #{comparable.id} - {comparable.fuente}",
                "precio": format_clp(comparable_data["precio_clp"]),
                "m2": f"{comparable.m2_construidos:g} m²"
                if comparable.m2_construidos
                else "Sin dato",
                "dormitorios": comparable.dormitorios
                if comparable.dormitorios is not None
                else "Sin dato",
                "distancia": calcular_distancia_texto(comparable),
                "similitud": similitud,
                "ranking": ranking,
                "destacado": ranking <= 3,
            }
        )

    table_rows = []
    for fila in filas[:10]:
        row_class = ' class="similar-row"' if fila["destacado"] else ""
        similitud = escape(str(fila["similitud"]))
        badge_label = escape(str(fila["similitud"].capitalize()))
        table_rows.append(
            f"""
            <tr{row_class}>
                <td>
                    <strong>{escape(str(fila["titulo"]))}</strong>
                    <div class="table-subtitle">Ranking #{escape(str(fila["ranking"]))}</div>
                </td>
                <td>{escape(str(fila["precio"]))}</td>
                <td>{escape(str(fila["m2"]))}</td>
                <td>{escape(str(fila["dormitorios"]))}</td>
                <td>{escape(str(fila["distancia"]))}</td>
                <td><span class="relevance-badge {similitud}">{badge_label}</span></td>
            </tr>
            """
        )

    rows_html = "\n".join(table_rows)
    table_html = f"""
    <div class="comparables-table-wrap">
        <table class="comparables-table">
            <thead>
                <tr>
                    <th>Título</th>
                    <th>Precio</th>
                    <th>m²</th>
                    <th>Dormitorios</th>
                    <th>Distancia</th>
                    <th>Relevancia</th>
                </tr>
            </thead>
            <tbody>
                {rows_html}
            </tbody>
        </table>
    </div>
    """

    st.markdown(table_html, unsafe_allow_html=True)


def mostrar_card_comparable(comparable_data):
    comparable = comparable_data["listing"]
    titulo = f"Comparable #{comparable.id} - {comparable.fuente}"
    precio = format_clp(comparable_data["precio_clp"])
    m2 = f"{comparable.m2_construidos:g} m²" if comparable.m2_construidos else "Sin m²"
    dormitorios = (
        f"{comparable.dormitorios} dormitorios"
        if comparable.dormitorios is not None
        else "Dormitorios sin dato"
    )

    st.markdown(
        f"""
        <div class="comparable-card">
            <div class="comparable-title">{titulo}</div>
            <div class="comparable-price">{precio}</div>
            <div class="comparable-meta">
                <span>{m2}</span>
                <span>{dormitorios}</span>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


init_db()

st.set_page_config(page_title="Tasador Inmobiliario", layout="wide")
st.markdown(
    """
    <style>
        :root {
            --color-bg: #0e1117;
            --color-surface: #151922;
            --color-surface-soft: #1a1f2a;
            --color-surface-muted: #11151d;
            --color-border: #2a303b;
            --color-border-strong: #3a414f;
            --color-text: #e6e6e6;
            --color-heading: #f5f5f5;
            --color-muted: #9ca3af;
            --color-muted-strong: #c0c6d0;
            --color-accent: #8bd3c7;
            --color-accent-bg: #142520;
            --color-accent-soft: #19322c;
            --color-accent-border: #2d5c52;
            --color-positive: #8bd3c7;
            --color-positive-bg: #142520;
            --color-positive-soft: #19322c;
            --color-positive-border: #2d5c52;
            --color-warning: #d7bd7f;
            --color-warning-bg: #282416;
            --color-warning-soft: #332d1b;
            --color-warning-border: #5b4d28;
            --color-danger: #d98b8b;
            --color-danger-bg: #2a1a1d;
            --color-danger-soft: #3a2226;
            --color-info-bg: #172131;
            --color-info-border: #2f4058;
            --radius-card: 8px;
            --radius-pill: 8px;
            --shadow-card: 0 0 0 rgba(0, 0, 0, 0);
            --shadow-soft: 0 0 0 rgba(0, 0, 0, 0);
            --space-card: 20px;
            --space-sm: 10px;
            --space-md: 14px;
            --space-lg: 22px;
            --font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            --text-xs: 0.78rem;
            --text-sm: 0.84rem;
            --text-md: 0.9rem;
            --text-lg: 1.02rem;
            --text-xl: 1.35rem;
            --text-hero: 4.8rem;
        }

        html, body, [class*="stApp"] {
            background: var(--color-bg);
            color: var(--color-text);
            font-family: var(--font-family);
        }

        .stApp,
        [data-testid="stAppViewContainer"],
        [data-testid="stHeader"] {
            background: var(--color-bg);
        }

        [data-testid="stSidebar"],
        [data-testid="stToolbar"],
        [data-testid="stDecoration"] {
            background: var(--color-bg);
        }

        .block-container {
            max-width: 1180px;
            padding-top: 2.35rem;
            padding-bottom: 3.5rem;
        }

        h1, h2, h3 {
            letter-spacing: 0;
        }

        div[data-testid="stVerticalBlockBorderWrapper"] {
            border: 1px solid var(--color-border);
            border-radius: var(--radius-card);
            box-shadow: var(--shadow-card);
            background: var(--color-surface);
            padding: 2px;
            transition: transform 160ms ease, box-shadow 160ms ease, border-color 160ms ease;
        }

        div[data-testid="stVerticalBlockBorderWrapper"]:hover {
            border-color: var(--color-border);
            box-shadow: none;
        }

        div[data-testid="stMetric"] {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-card);
            padding: var(--space-card);
            box-shadow: var(--shadow-soft);
        }

        div[data-testid="stMetricLabel"] p {
            color: var(--color-muted);
            font-size: var(--text-sm);
        }

        div[data-testid="stMetricValue"] {
            color: var(--color-heading);
            font-weight: 750;
        }

        div.stButton > button {
            border-radius: var(--radius-card);
            border: 1px solid var(--color-accent-border);
            background: var(--color-accent-bg);
            color: var(--color-accent);
            font-weight: 750;
            min-height: 38px;
            font-size: 0.88rem;
            box-shadow: var(--shadow-soft);
            transition: transform 140ms ease, box-shadow 140ms ease, background 140ms ease;
        }

        div.stButton > button:hover {
            border-color: var(--color-accent);
            background: var(--color-accent-soft);
            color: var(--color-accent);
            transform: none;
            box-shadow: none;
        }

        div.stButton > button:active {
            transform: translateY(0);
            box-shadow: none;
        }

        label,
        [data-testid="stWidgetLabel"],
        [data-testid="stMarkdownContainer"] p {
            color: var(--color-text);
        }

        [data-testid="stWidgetLabel"] {
            min-height: auto;
            margin-bottom: 2px;
        }

        [data-testid="stWidgetLabel"] p {
            color: var(--color-muted);
            font-size: 0.76rem;
            font-weight: 700;
            line-height: 1.2;
        }

        div[data-testid="stSelectbox"],
        div[data-testid="stNumberInput"],
        div[data-testid="stCheckbox"],
        div[data-testid="stRadio"] {
            margin-bottom: 0.35rem;
        }

        div[data-baseweb="select"] > div,
        div[data-baseweb="input"] input,
        div[data-baseweb="base-input"],
        div[data-testid="stNumberInput"] input {
            background: var(--color-surface-muted);
            border-color: var(--color-border);
            color: var(--color-text);
            min-height: 34px;
            font-size: 0.88rem;
        }

        div[data-baseweb="select"] > div,
        div[data-baseweb="base-input"] {
            min-height: 34px;
        }

        div[data-testid="stNumberInput"] input {
            padding: 4px 10px;
        }

        div[data-baseweb="select"] span,
        div[data-testid="stNumberInput"] input {
            color: var(--color-text);
        }

        div[data-testid="stAlert"] {
            background: var(--color-surface-soft);
            border: 1px solid var(--color-border);
            color: var(--color-text);
        }

        div[data-testid="stAlert"] p {
            color: var(--color-muted-strong);
        }

        div[data-baseweb="select"] > div:hover,
        div[data-baseweb="input"] input:hover,
        div[data-testid="stNumberInput"] input:hover {
            border-color: var(--color-border-strong);
        }

        div[data-baseweb="popover"],
        div[data-baseweb="menu"] {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            color: var(--color-text);
        }

        div[role="option"],
        div[role="listbox"] {
            background: var(--color-surface);
            color: var(--color-text);
        }

        div[role="option"]:hover {
            background: var(--color-surface-soft);
        }

        div[data-testid="stRadio"] label,
        div[data-testid="stCheckbox"] label,
        div[data-testid="stRadio"] p,
        div[data-testid="stCheckbox"] p {
            color: var(--color-text);
        }

        div[data-testid="stRadio"] [role="radiogroup"] {
            background: var(--color-surface-muted);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-card);
            padding: 5px 8px;
        }

        div[data-testid="stCheckbox"] {
            background: var(--color-surface-muted);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-card);
            padding: 5px 8px;
        }

        input,
        textarea,
        select {
            caret-color: var(--color-text);
        }

        .eyebrow {
            color: var(--color-muted-strong);
            font-size: var(--text-md);
            font-weight: 700;
            letter-spacing: 0;
            text-transform: uppercase;
            margin-bottom: 4px;
        }

        .page-title {
            color: var(--color-heading);
            font-size: 2.18rem;
            line-height: 1.12;
            font-weight: 800;
            margin: 0 0 var(--space-sm) 0;
        }

        .page-subtitle {
            color: var(--color-muted-strong);
            font-size: 0.98rem;
            line-height: 1.55;
            max-width: 760px;
            margin-bottom: 1.85rem;
        }

        .section-title {
            color: var(--color-heading);
            font-size: var(--text-lg);
            font-weight: 750;
            margin-bottom: 6px;
        }

        .section-copy {
            color: var(--color-muted);
            font-size: var(--text-md);
            line-height: 1.5;
            margin-bottom: var(--space-lg);
        }

        .input-group-label {
            color: var(--color-muted-strong);
            font-size: 0.72rem;
            font-weight: 850;
            letter-spacing: 0;
            text-transform: uppercase;
            margin: 12px 0 6px;
        }

        .input-helper {
            color: var(--color-muted);
            font-size: 0.82rem;
            line-height: 1.35;
            margin-bottom: 10px;
        }

        .comparable-card {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-card);
            box-shadow: var(--shadow-soft);
            padding: 14px var(--space-card);
            margin-bottom: var(--space-md);
            transition: transform 160ms ease, box-shadow 160ms ease, border-color 160ms ease;
        }

        .comparable-card:hover {
            transform: translateY(-2px);
            border-color: var(--color-border-strong);
            box-shadow: none;
        }

        .comparable-title {
            font-weight: 750;
            color: var(--color-text);
            margin-bottom: 6px;
        }

        .comparable-price {
            font-size: var(--text-lg);
            font-weight: 800;
            color: var(--color-positive);
            margin-bottom: var(--space-sm);
        }

        .comparable-meta {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            color: var(--color-muted);
            font-size: 0.9rem;
        }

        .status-note {
            color: var(--color-muted);
            font-size: 0.88rem;
            margin-top: var(--space-md);
        }

        .result-hero {
            text-align: center;
            min-height: 260px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 52px 34px 46px;
            margin: 10px 0 28px;
            border: 1px solid var(--color-border-strong);
            border-radius: var(--radius-card);
            background: var(--color-surface-muted);
            animation: resultFadeIn 360ms ease both;
        }

        .result-layer-stack {
            display: grid;
            gap: 22px;
            margin: 10px 0 30px;
        }

        .result-layer-stack .result-hero {
            min-height: 255px;
            margin: 0;
        }

        .insight-layer {
            border: 1px solid var(--color-border);
            border-radius: var(--radius-card);
            background: var(--color-surface);
            padding: 18px 20px;
            animation: resultFadeIn 420ms ease both;
        }

        .insight-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 10px;
        }

        .insight-label {
            color: var(--color-muted);
            font-size: var(--text-xs);
            font-weight: 850;
            text-transform: uppercase;
        }

        .result-label {
            color: var(--color-muted);
            font-size: var(--text-xs);
            font-weight: 750;
            text-transform: uppercase;
            margin-bottom: 14px;
        }

        .result-value {
            color: var(--color-heading);
            font-size: var(--text-hero);
            line-height: 1;
            font-weight: 850;
            margin-bottom: 14px;
        }

        .market-state-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: var(--radius-pill);
            border: 1px solid var(--color-border);
            background: var(--color-surface-soft);
            color: var(--color-muted-strong);
            font-size: 0.78rem;
            font-weight: 850;
            letter-spacing: 0;
            line-height: 1;
            padding: 7px 10px;
            margin-bottom: 0;
            text-transform: uppercase;
        }

        .market-state-badge.neutral {
            color: var(--color-positive);
            background: var(--color-positive-bg);
            border-color: var(--color-positive-border);
        }

        .market-state-badge.low {
            color: var(--color-muted-strong);
            background: var(--color-info-bg);
            border-color: var(--color-info-border);
        }

        .market-state-badge.high {
            color: var(--color-warning);
            background: var(--color-warning-bg);
            border-color: var(--color-warning-border);
        }

        .result-support {
            display: flex;
            justify-content: center;
            gap: 28px;
            flex-wrap: wrap;
            color: var(--color-muted-strong);
            font-size: 0.86rem;
            font-weight: 450;
        }

        .result-support strong {
            color: var(--color-text);
            font-weight: 650;
        }

        .layer-heading {
            margin: 32px 0 14px;
        }

        .layer-heading .section-copy {
            margin-bottom: 0;
        }

        .interpretation-card {
            border-radius: var(--radius-card);
            padding: 14px var(--space-card);
            margin: -4px 0 var(--space-lg);
            border: 1px solid var(--color-border);
            animation: resultFadeIn 420ms ease both;
            transition: transform 160ms ease, box-shadow 160ms ease;
        }

        .interpretation-card:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-soft);
        }

        .interpretation-card.interpretation-inline {
            margin: 0 18px 0;
            border-radius: var(--radius-card);
            box-shadow: none;
        }

        .interpretation-card.low {
            background: var(--color-info-bg);
            border-color: var(--color-info-border);
        }

        .interpretation-card.neutral {
            background: var(--color-positive-bg);
            border-color: var(--color-positive-border);
        }

        .interpretation-card.high {
            background: var(--color-warning-bg);
            border-color: var(--color-warning-border);
        }

        .interpretation-copy {
            color: var(--color-muted-strong);
            font-size: 0.9rem;
            line-height: 1.4;
        }

        .auto-summary {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-card);
            padding: 16px var(--space-card);
            margin-bottom: var(--space-lg);
            animation: resultFadeIn 480ms ease both;
            transition: transform 160ms ease, box-shadow 160ms ease, border-color 160ms ease;
        }

        .auto-summary:hover {
            transform: translateY(-1px);
            border-color: var(--color-border-strong);
            box-shadow: var(--shadow-soft);
        }

        .auto-summary.auto-summary-inline {
            margin: 12px 18px 18px;
            box-shadow: none;
        }

        .insight-layer .auto-summary.auto-summary-inline {
            margin: 12px 0 0;
            background: var(--color-surface-soft);
        }

        .auto-summary-title {
            color: var(--color-text);
            font-size: 0.95rem;
            font-weight: 850;
            margin-bottom: 5px;
        }

        .auto-summary-copy {
            color: var(--color-muted-strong);
            font-size: var(--text-md);
            line-height: 1.45;
        }

        .key-metric-card {
            min-height: 102px;
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-card);
            box-shadow: var(--shadow-soft);
            padding: 18px 16px 16px;
            margin-bottom: var(--space-lg);
            transition: transform 160ms ease, box-shadow 160ms ease, border-color 160ms ease;
        }

        .key-metric-card:hover {
            transform: none;
            border-color: var(--color-border);
            box-shadow: none;
        }

        .key-metric-title {
            color: var(--color-muted);
            font-size: 0.72rem;
            font-weight: 800;
            text-transform: uppercase;
            line-height: 1.25;
            margin-top: 8px;
            margin-bottom: 0;
        }

        .key-metric-value {
            color: var(--color-heading);
            font-size: 1.68rem;
            line-height: 1.05;
            font-weight: 850;
            margin-bottom: 0;
        }

        .key-metric-copy {
            color: var(--color-muted);
            font-size: 0.78rem;
            line-height: 1.25;
            margin-top: 5px;
        }

        .comparables-summary {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-card);
            box-shadow: var(--shadow-soft);
            padding: 18px var(--space-card);
            margin: 8px 0 28px;
            animation: resultFadeIn 360ms ease both;
            transition: transform 160ms ease, box-shadow 160ms ease, border-color 160ms ease;
        }

        .comparables-summary:hover {
            transform: none;
            border-color: var(--color-border);
            box-shadow: none;
        }

        .comparables-summary-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: var(--space-md);
            margin-bottom: var(--space-md);
        }

        .comparables-summary-header .section-copy {
            margin-bottom: 0;
        }

        .summary-status {
            display: inline-flex;
            align-items: center;
            border: 1px solid var(--color-info-border);
            border-radius: var(--radius-pill);
            background: var(--color-info-bg);
            color: var(--color-muted-strong);
            font-size: var(--text-xs);
            font-weight: 800;
            padding: 5px 8px;
            white-space: nowrap;
        }

        .comparables-summary-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 12px;
        }

        .summary-item {
            background: var(--color-surface-soft);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-card);
            padding: 14px;
            min-height: 92px;
        }

        .summary-label {
            color: var(--color-muted);
            font-size: var(--text-xs);
            font-weight: 800;
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        .summary-value {
            color: var(--color-heading);
            font-size: 1.05rem;
            line-height: 1.25;
            font-weight: 850;
        }

        .scatter-card {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-card);
            box-shadow: var(--shadow-soft);
            padding: var(--space-card);
            margin: 4px 0 var(--space-lg);
            transition: transform 160ms ease, box-shadow 160ms ease, border-color 160ms ease;
        }

        .scatter-card:hover {
            transform: translateY(-1px);
            border-color: var(--color-border-strong);
            box-shadow: none;
        }

        .scatter-header {
            display: flex;
            justify-content: space-between;
            gap: var(--space-md);
            align-items: flex-start;
            margin-bottom: 4px;
        }

        .scatter-header .section-copy {
            margin-bottom: 0;
        }

        .scatter-legend {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            color: var(--color-muted);
            font-size: var(--text-xs);
            white-space: nowrap;
        }

        .legend-dot {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 999px;
            margin-right: 4px;
        }

        .legend-dot.market {
            background: var(--color-muted);
        }

        .legend-dot.target {
            background: var(--color-accent);
        }

        .scatter-svg {
            width: 100%;
            height: auto;
            display: block;
            margin-top: 6px;
        }

        .axis-line {
            stroke: var(--color-border-strong);
            stroke-width: 1;
        }

        .axis-label {
            fill: var(--color-muted);
            font-size: 11px;
            font-weight: 650;
        }

        .scatter-point {
            fill: var(--color-muted);
            opacity: 0.72;
            transition: opacity 140ms ease, transform 140ms ease;
        }

        .scatter-target {
            fill: var(--color-accent);
            stroke: var(--color-surface);
            stroke-width: 3;
            filter: none;
        }

        .scatter-label {
            fill: var(--color-accent);
            font-size: 12px;
            font-weight: 850;
        }

        .factor-row {
            display: grid;
            grid-template-columns: minmax(120px, 0.9fr) minmax(160px, 1.8fr) minmax(56px, auto);
            align-items: center;
            gap: 14px;
            border: 1px solid var(--color-border);
            border-radius: var(--radius-card);
            padding: 14px 16px;
            margin-bottom: 10px;
            background: var(--color-surface);
            transition: transform 160ms ease, box-shadow 160ms ease, border-color 160ms ease;
        }

        .factor-row:hover {
            transform: none;
            border-color: var(--color-border);
            box-shadow: var(--shadow-soft);
        }

        .factor-name {
            color: var(--color-text);
            font-size: 0.9rem;
            font-weight: 800;
            line-height: 1.2;
        }

        .factor-detail {
            grid-column: 1 / -1;
            color: var(--color-muted);
            font-size: 0.76rem;
            line-height: 1.3;
            margin-top: -4px;
        }

        .factor-impact {
            font-size: 0.9rem;
            font-weight: 850;
            white-space: nowrap;
            text-align: right;
            font-variant-numeric: tabular-nums;
        }

        .factor-impact.positive {
            color: var(--color-muted-strong);
        }

        .factor-impact.negative {
            color: var(--color-muted);
        }

        .factor-track {
            height: 7px;
            background: var(--color-surface-muted);
            border-radius: var(--radius-pill);
            overflow: hidden;
            border: 1px solid var(--color-border);
        }

        .factor-bar {
            height: 100%;
            border-radius: var(--radius-pill);
            animation: growBar 520ms ease both;
            transform-origin: left center;
        }

        .factor-bar.positive {
            background: var(--color-accent);
        }

        .factor-bar.negative {
            background: var(--color-muted);
        }

        .comparables-table-wrap {
            border: 1px solid var(--color-border);
            border-radius: var(--radius-card);
            overflow: hidden;
            background: var(--color-surface);
        }

        .comparables-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }

        .comparables-table th {
            background: var(--color-surface-muted);
            color: var(--color-muted);
            font-size: var(--text-xs);
            font-weight: 800;
            text-transform: uppercase;
            text-align: left;
            padding: 12px 14px;
            border-bottom: 1px solid var(--color-border);
        }

        .comparables-table td {
            color: var(--color-text);
            padding: 13px 14px;
            border-bottom: 1px solid var(--color-border);
            vertical-align: top;
        }

        .comparables-table tbody tr {
            transition: background 120ms ease, transform 120ms ease;
        }

        .comparables-table tbody tr:hover {
            background: var(--color-surface-soft);
            transform: translateX(2px);
        }

        .comparables-table tbody tr.similar-row {
            background: var(--color-positive-bg);
        }

        .comparables-table tbody tr.similar-row:hover {
            background: var(--color-positive-soft);
        }

        .table-subtitle {
            color: var(--color-muted);
            font-size: var(--text-xs);
            margin-top: 3px;
        }

        .relevance-badge {
            display: inline-flex;
            align-items: center;
            border-radius: var(--radius-pill);
            padding: 4px 8px;
            font-size: 0.76rem;
            font-weight: 800;
            border: 1px solid transparent;
            transition: transform 140ms ease;
        }

        .relevance-badge:hover {
            transform: scale(1.03);
        }

        .relevance-badge.alta {
            color: var(--color-positive);
            background: var(--color-positive-soft);
            border-color: var(--color-positive-border);
        }

        .relevance-badge.media {
            color: var(--color-warning);
            background: var(--color-warning-soft);
            border-color: var(--color-warning-border);
        }

        .relevance-badge.baja {
            color: var(--color-muted);
            background: var(--color-surface-soft);
            border-color: var(--color-border);
        }

        @keyframes resultFadeIn {
            from {
                opacity: 0;
                transform: translateY(8px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes growBar {
            from {
                transform: scaleX(0);
            }
            to {
                transform: scaleX(1);
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                scroll-behavior: auto !important;
                transition-duration: 0.01ms !important;
            }
        }

        @media (max-width: 900px) {
            .comparables-summary-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .factor-row {
                grid-template-columns: minmax(100px, 0.9fr) minmax(120px, 1.4fr) minmax(54px, auto);
            }
        }

        @media (max-width: 560px) {
            .comparables-summary-header {
                display: block;
            }

            .summary-status {
                margin-top: 10px;
            }

            .comparables-summary-grid {
                grid-template-columns: 1fr;
            }

            .factor-row {
                grid-template-columns: 1fr;
                gap: 8px;
            }

            .factor-impact {
                text-align: left;
            }
        }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <div class="eyebrow">Tasación inmobiliaria</div>
    <div class="page-title">Motor de Tasación Inmobiliaria</div>
    <div class="page-subtitle">
        El valor se calcula en base a comparables reales del mercado.
    </div>
    """,
    unsafe_allow_html=True,
)

input_col, result_col = st.columns([0.82, 1.58], gap="large")

with input_col:
    with st.container(border=True):
        st.markdown(
            """
            <div class="section-title">Datos de la propiedad</div>
            <div class="input-helper">Completa los campos clave para estimar el valor.</div>
            """,
            unsafe_allow_html=True,
        )

        st.markdown('<div class="input-group-label">Ubicación</div>', unsafe_allow_html=True)
        comuna = st.selectbox("Comuna", list(COMUNA_COORDENADAS.keys()))
        direccion = st.text_input(
            "Dirección",
            placeholder="Opcional, por ahora se usa como referencia interna",
        )
        usar_coordenadas_manuales = st.checkbox("Usar lat/lon manual para pruebas")

        lat_manual = None
        lon_manual = None

        if usar_coordenadas_manuales:
            geo_col_a, geo_col_b = st.columns(2)
            with geo_col_a:
                lat_manual = st.number_input(
                    "Latitud",
                    value=COMUNA_COORDENADAS.get(comuna, (0.0, 0.0))[0],
                    format="%.6f",
                )
            with geo_col_b:
                lon_manual = st.number_input(
                    "Longitud",
                    value=COMUNA_COORDENADAS.get(comuna, (0.0, 0.0))[1],
                    format="%.6f",
                )

        st.markdown('<div class="input-group-label">Superficie</div>', unsafe_allow_html=True)
        surface_col_a, surface_col_b = st.columns(2)
        with surface_col_a:
            m2_construidos = st.number_input("Construida (m²)", value=100)
        with surface_col_b:
            m2_terreno = st.number_input("Terreno (m²)", value=200)

        st.markdown('<div class="input-group-label">Características</div>', unsafe_allow_html=True)
        detail_col_a, detail_col_b = st.columns(2)
        with detail_col_a:
            dormitorios = st.number_input("Dormitorios", value=3)
            estacionamientos = st.number_input("Estacionamientos", value=1)
        with detail_col_b:
            banos = st.number_input("Baños", value=2)
            ano_construccion = st.number_input("Año", value=2015)

        piscina = st.checkbox("¿Tiene piscina?")
        st.markdown('<div class="input-group-label">Nivel de detalle</div>', unsafe_allow_html=True)
        vista = st.radio(
            "Vista",
            ["Simple", "Avanzada"],
            horizontal=True,
        )
        calcular = st.button("Calcular valor estimado", use_container_width=True)

with result_col:
    if not calcular:
        with st.container(border=True):
            st.markdown(
                """
                <div class="section-title">Resultados</div>
                <div class="section-copy">Completa los datos y calcula una tasación para ver el valor estimado.</div>
                """,
                unsafe_allow_html=True,
            )
            st.info("Los resultados aparecerán aquí.")
    else:
        lat_aproximada, lon_aproximada = geocode_simple(comuna, direccion)
        lat_objetivo = float(lat_manual) if usar_coordenadas_manuales else lat_aproximada
        lon_objetivo = float(lon_manual) if usar_coordenadas_manuales else lon_aproximada

        property_data = {
            "comuna": comuna,
            "lat": lat_objetivo,
            "lon": lon_objetivo,
            "m2_construidos": float(m2_construidos),
            "m2_terreno": float(m2_terreno),
            "dormitorios": int(dormitorios),
            "banos": int(banos),
            "estacionamientos": int(estacionamientos),
            "piscina": bool(piscina),
            "ano_construccion": int(ano_construccion),
        }

        with SessionLocal() as db:
            valor = calcular_tasacion_comparables(db, property_data)
            comparables = buscar_comparables(
                db,
                property_data["comuna"],
                property_data["m2_construidos"],
                property_data["dormitorios"],
                property_data["banos"],
                property_data["estacionamientos"],
            )

        if valor is None:
            valor = calcular_tasacion(
                property_data["comuna"],
                property_data["m2_construidos"],
                property_data["m2_terreno"],
                property_data["dormitorios"],
                property_data["banos"],
                property_data["estacionamientos"],
                property_data["piscina"],
                property_data["ano_construccion"],
            )

        property_id, listing_id = save_listing(property_data, int(valor))
        comparables_usados = preparar_comparables_usados(property_data, comparables)
        precio_promedio_m2 = calcular_precio_promedio_m2(comparables_usados)
        superficie_promedio = calcular_superficie_promedio(comparables_usados)
        desviacion_estimada = calcular_desviacion_estimada(comparables_usados)
        factores_tasacion = calcular_factores_tasacion(
            property_data,
            comparables_usados,
        )
        rango_minimo = valor * 0.95
        rango_maximo = valor * 1.05
        precio_resultado_m2 = valor / property_data["m2_construidos"]
        interpretacion = interpretar_resultado(precio_resultado_m2, precio_promedio_m2)
        resumen_automatico = generar_resumen_automatico(
            interpretacion,
            factores_tasacion,
        )

        with st.container(border=True):
            st.markdown(
                """
                <div class="section-title">Resultados de tasación</div>
                <div class="section-copy">Estimación calculada con comparables y fallback del modelo base cuando no hay datos suficientes.</div>
                """,
                unsafe_allow_html=True,
            )

            st.markdown(
                f"""
                <div class="result-layer-stack">
                    <section class="result-hero">
                        <div class="result-label">Valor estimado</div>
                        <div class="result-value">{format_clp(valor)}</div>
                        <div class="result-support">
                            <span>Rango estimado: <strong>{format_clp(rango_minimo)} - {format_clp(rango_maximo)}</strong></span>
                            <span>Precio por m²: <strong>{format_clp(precio_resultado_m2)}</strong></span>
                        </div>
                    </section>
                    <section class="insight-layer">
                        <div class="insight-header">
                            <span class="market-state-badge {interpretacion["clase"]}">{escape(interpretacion["estado"])}</span>
                            <span class="insight-label">Insight</span>
                        </div>
                        <div class="interpretation-copy">{escape(interpretacion["descripcion"])}</div>
                        <div class="auto-summary auto-summary-inline">
                            <div class="auto-summary-title">Resumen automático</div>
                            <div class="auto-summary-copy">{escape(resumen_automatico)}</div>
                        </div>
                    </section>
                </div>
                """,
                unsafe_allow_html=True,
            )

            st.markdown(
                """
                <div class="layer-heading">
                    <div class="section-title">Métricas clave</div>
                    <div class="section-copy">Contexto rápido para leer la estimación.</div>
                </div>
                """,
                unsafe_allow_html=True,
            )

            if vista == "Simple":
                metric_cols = st.columns(4)
                with metric_cols[0]:
                    mostrar_metric_card(
                        "Precio promedio zona",
                        format_clp(precio_promedio_m2)
                        if precio_promedio_m2
                        else "Sin datos",
                    )
                with metric_cols[1]:
                    mostrar_metric_card(
                        "Comparables",
                        str(len(comparables_usados)),
                    )
                with metric_cols[2]:
                    mostrar_metric_card(
                        "Superficie promedio",
                        format_m2(superficie_promedio),
                    )
                with metric_cols[3]:
                    mostrar_metric_card(
                        "Desviación",
                        format_percent(desviacion_estimada),
                    )
                mostrar_resumen_comparables(comparables_usados)
            else:
                metric_cols = st.columns(4)
                with metric_cols[0]:
                    mostrar_metric_card(
                        "Precio promedio zona",
                        format_clp(precio_promedio_m2)
                        if precio_promedio_m2
                        else "Sin datos",
                    )
                with metric_cols[1]:
                    mostrar_metric_card(
                        "Cantidad de comparables",
                        str(len(comparables_usados)),
                    )
                with metric_cols[2]:
                    mostrar_metric_card(
                        "Superficie promedio",
                        format_m2(superficie_promedio),
                    )
                with metric_cols[3]:
                    mostrar_metric_card(
                        "Desviación",
                        format_percent(desviacion_estimada),
                    )

                mostrar_resumen_comparables(comparables_usados)

                st.markdown(
                    """
                    <div class="layer-heading">
                        <div class="section-title">Factores de tasación</div>
                        <div class="section-copy">Principales variables que explican la estimación.</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

                for factor in factores_tasacion:
                    mostrar_factor_tasacion(factor)

            st.markdown(
                f"""
                <div class="status-note">
                    Guardado en base de datos: property #{property_id}, listing #{listing_id}
                </div>
                """,
                unsafe_allow_html=True,
            )

        if vista == "Avanzada" and not comparables_usados:
            with st.container(border=True):
                st.warning("No se encontraron comparables válidos para mostrar.")
