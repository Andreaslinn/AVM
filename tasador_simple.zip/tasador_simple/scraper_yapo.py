from __future__ import annotations

import re
import time
from datetime import date, datetime
from typing import Optional
from urllib.parse import urljoin, urlparse, urlunparse

from bs4 import BeautifulSoup
from sqlalchemy import or_, select
from selenium import webdriver
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from database import SessionLocal, init_db
from models import Listing, PriceHistory


DEFAULT_WAIT_SECONDS = 20
MIN_HTML_LENGTH = 500
MIN_SALE_PRICE_CLP = 10_000_000
BASE_URL = "https://www.yapo.cl"
EXAMPLE_URL = (
    "https://www.yapo.cl/bienes-raices-venta-de-propiedades-apartamentos/"
    "region-metropolitana-nunoa"
)
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/123.0.0.0 Safari/537.36"
)
CARD_SELECTORS = [
    "article",
    "li[class*='listing']",
    "li[class*='Listing']",
    "div[class*='listing']",
    "div[class*='Listing']",
    "div[class*='card']",
    "div[class*='Card']",
]


def iniciar_driver():
    options = Options()
    options.add_argument(f"--user-agent={USER_AGENT}")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--no-sandbox")
    options.add_argument("--start-maximized")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)

    # headless=False para validar visualmente que cargan propiedades reales.
    return webdriver.Chrome(service=Service(), options=options)


def fetch_page(url):
    driver = None

    try:
        driver = iniciar_driver()
        driver.get(url)

        wait = WebDriverWait(driver, DEFAULT_WAIT_SECONDS)
        wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))

        # Yapo carga parte del contenido dinamicamente; esperamos y luego scrolleamos.
        time.sleep(5)
        scroll_page(driver)
        wait_for_possible_listings(driver)

        return driver.page_source
    except TimeoutException as error:
        print(f"Timeout real cargando pagina con Selenium: {error}")
        return ""
    except WebDriverException as error:
        print(f"Error de red o Selenium cargando pagina: {error}")
        return ""
    except Exception as error:
        print(f"Error inesperado cargando pagina: {error}")
        return ""
    finally:
        if driver is not None:
            driver.quit()


def parse_listings(html):
    if not is_html_processable(html):
        return []

    soup = BeautifulSoup(html, "html.parser")
    content_root = soup.select_one("main") or soup
    cards = find_listing_cards(content_root)
    listings = []
    seen_links = set()

    for card in cards:
        listing = parse_listing_card(card)
        title = clean_text(listing["titulo"])
        price = listing["precio"]
        link = listing["link"]
        raw_text = clean_text(listing["raw_text"])
        normalized_price = normalize_price(price)

        if not link:
            print("Listing descartado por falta de URL")
            continue

        if not title or not price:
            continue

        if normalized_price is None:
            continue

        if link in seen_links:
            continue

        if is_navigation_link(link, title):
            continue

        if not is_valid_sale_price(normalized_price):
            continue

        attributes_text = " ".join(value for value in [title, raw_text] if value)
        parsed_listing = {
            "titulo": title,
            "precio_texto": price,
            "precio_clp": normalized_price["precio_clp"],
            "precio_uf": normalized_price["precio_uf"],
            "url": link,
            "link": link,
            "source_listing_id": extract_source_listing_id(link),
            "comuna": extract_comuna(attributes_text),
            "m2_construidos": extract_m2_from_text(attributes_text),
            "m2_terreno": None,
            "m2_util": None,
            "m2_total": None,
            "dormitorios": extract_number_near_keywords(
                attributes_text,
                ["dormitorio", "dormitorios", "dorm"],
            ),
            "banos": extract_number_near_keywords(
                attributes_text,
                ["bano", "banos", "baño", "baños"],
            ),
            "estacionamientos": extract_number_near_keywords(
                attributes_text,
                ["estacionamiento", "estacionamientos", "estac"],
            ),
            "fecha_publicacion": None,
        }

        if not has_quality_signal(**extract_quality_fields(parsed_listing)):
            continue

        seen_links.add(link)
        listings.append(parsed_listing)

    return listings


def scrape(url):
    html = fetch_page(url)

    if not is_html_processable(html):
        return []

    try:
        raw_results = parse_raw_listings(html)
        filtered_results = parse_listings(html)
        print(f"Cantidad original: {len(raw_results)}")
        print(f"Cantidad filtrada: {len(filtered_results)}")
        return filtered_results
    except Exception as error:
        print(f"Error parseando listings: {error}")
        return []


def scrape_and_save(url):
    init_db()
    items = scrape(url)
    saved_count = 0
    updated_count = 0

    with SessionLocal() as db:
        for item in items:
            try:
                listing = save_listing(db, item)

                if listing is None:
                    db.rollback()
                    continue

                db.commit()
                if getattr(listing, "_was_created", False):
                    saved_count += 1
                else:
                    updated_count += 1
            except Exception as error:
                db.rollback()
                print(f"Error guardando listing: {error}")

    print(f"Total scrapeados: {len(items)}")
    print(f"Total guardados: {saved_count}")
    print(f"Total actualizados: {updated_count}")
    return saved_count


def save_listing(db, item):
    precio_clp = positive_or_none(item.get("precio_clp"))
    precio_uf = positive_or_none(item.get("precio_uf"))

    listing_data = normalize_listing_item(item)

    if listing_data["url"] is None:
        print("Listing descartado por falta de URL")
        return None

    if listing_data["titulo"] is None:
        return None

    if not has_valid_price(precio_clp, precio_uf):
        return None

    if not has_quality_signal(**extract_quality_fields(listing_data)):
        return None

    listing = find_existing_listing(
        db,
        fuente="yapo",
        link=listing_data["link"],
        source_listing_id=listing_data["source_listing_id"],
        url=listing_data["url"],
    )

    was_created = listing is None
    old_precio_clp = listing.precio_clp if listing is not None else None
    old_precio_uf = listing.precio_uf if listing is not None else None

    if listing is None:
        listing = Listing(
            property_id=None,
            fuente="yapo",
            source_listing_id=listing_data["source_listing_id"],
            url=listing_data["url"],
            link=listing_data["link"],
            status="active",
        )
        db.add(listing)
        print(f"nuevo listing insertado: {listing_data['link']}")
    else:
        print(f"listing ya existente actualizado: {listing_data['link']}")

    listing.source_listing_id = listing_data["source_listing_id"] or listing.source_listing_id
    listing.url = listing_data["url"] or listing.url
    listing.link = listing_data["link"] or listing.link
    listing.status = "active"
    listing.titulo = listing_data["titulo"] or listing.titulo
    listing.precio_clp = precio_clp
    listing.precio_uf = precio_uf
    listing.comuna = listing_data["comuna"]
    listing.lat = listing_data["lat"]
    listing.lon = listing_data["lon"]
    listing.m2_construidos = listing_data["m2_construidos"]
    listing.m2_terreno = listing_data["m2_terreno"]
    listing.m2_util = listing_data["m2_util"]
    listing.m2_total = listing_data["m2_total"]
    listing.dormitorios = listing_data["dormitorios"]
    listing.banos = listing_data["banos"]
    listing.estacionamientos = listing_data["estacionamientos"]
    listing.fecha_publicacion = listing_data["fecha_publicacion"]
    listing.fecha_captura = date.today()

    price_changed = old_precio_clp != precio_clp or old_precio_uf != precio_uf

    if not was_created and price_changed:
        print(f"precio actualizado en listing existente: {listing_data['link']}")

    db.flush()
    listing._was_created = was_created
    add_price_history_if_needed(
        db,
        listing,
        precio_clp_anterior=old_precio_clp,
        precio_uf_anterior=old_precio_uf,
        precio_clp_nuevo=precio_clp,
        precio_uf_nuevo=precio_uf,
        was_created=was_created,
    )
    return listing


def normalize_listing_item(item):
    link = normalize_listing_url(clean_text(item.get("link") or item.get("url"))) or None
    url = normalize_listing_url(clean_text(item.get("url") or item.get("link"))) or None
    title = clean_text(item.get("titulo")) or None
    raw_text = clean_text(item.get("raw_text") or item.get("texto")) or None
    attributes_text = " ".join(value for value in [title, raw_text] if value)
    source_listing_id = clean_text(
        item.get("source_listing_id") or extract_source_listing_id(url)
    ) or None

    return {
        "source_listing_id": source_listing_id,
        "url": url,
        "link": link,
        "titulo": title,
        "comuna": clean_text(item.get("comuna")) or extract_comuna(attributes_text),
        "lat": float_or_none(item.get("lat")),
        "lon": float_or_none(item.get("lon")),
        "m2_construidos": positive_or_none(item.get("m2_construidos"))
        or extract_m2_from_text(attributes_text),
        "m2_terreno": positive_or_none(item.get("m2_terreno")),
        "m2_util": positive_or_none(item.get("m2_util")),
        "m2_total": positive_or_none(item.get("m2_total")),
        "dormitorios": positive_int_or_none(item.get("dormitorios"))
        or extract_number_near_keywords(
            attributes_text,
            ["dormitorio", "dormitorios", "dorm"],
        ),
        "banos": positive_int_or_none(item.get("banos"))
        or extract_number_near_keywords(
            attributes_text,
            ["bano", "banos", "baño", "baños"],
        ),
        "estacionamientos": non_negative_int_or_none(item.get("estacionamientos"))
        if item.get("estacionamientos") is not None
        else extract_number_near_keywords(
            attributes_text,
            ["estacionamiento", "estacionamientos", "estac"],
        ),
        "fecha_publicacion": item.get("fecha_publicacion"),
    }


def find_existing_listing(db, fuente, link=None, source_listing_id=None, url=None):
    link = normalize_listing_url(link)
    url = normalize_listing_url(url)

    if link:
        statement = select(Listing).where(
            Listing.fuente == fuente,
            or_(
                Listing.link == link,
                Listing.link.like(f"{link}?%"),
                Listing.link.like(f"{link}#%"),
            ),
        )
        listing = db.execute(statement).scalars().first()

        if listing is not None:
            return listing

    if url:
        statement = select(Listing).where(
            Listing.fuente == fuente,
            or_(
                Listing.url == url,
                Listing.url.like(f"{url}?%"),
                Listing.url.like(f"{url}#%"),
            ),
        )
        listing = db.execute(statement).scalars().first()

        if listing is not None:
            return listing

    if source_listing_id:
        statement = select(Listing).where(
            Listing.fuente == fuente,
            Listing.source_listing_id == source_listing_id,
        )
        return db.execute(statement).scalar_one_or_none()

    return None


def add_price_history_if_needed(
    db,
    listing,
    precio_clp_anterior,
    precio_uf_anterior,
    precio_clp_nuevo,
    precio_uf_nuevo,
    was_created=False,
):
    price_changed = (
        precio_clp_anterior != precio_clp_nuevo
        or precio_uf_anterior != precio_uf_nuevo
    )

    if not was_created and not price_changed:
        return

    statement = (
        select(PriceHistory)
        .where(PriceHistory.listing_id == listing.id)
        .order_by(PriceHistory.fecha_cambio.desc(), PriceHistory.id.desc())
        .limit(1)
    )
    last_price = db.execute(statement).scalar_one_or_none()

    if (
        last_price is not None
        and last_price.precio_clp_nuevo == precio_clp_nuevo
        and last_price.precio_uf_nuevo == precio_uf_nuevo
        and last_price.fecha_captura == listing.fecha_captura
    ):
        return

    db.add(
        PriceHistory(
            listing_id=listing.id,
            precio_clp=precio_clp_nuevo,
            precio_uf=precio_uf_nuevo,
            precio_clp_anterior=precio_clp_anterior,
            precio_uf_anterior=precio_uf_anterior,
            precio_clp_nuevo=precio_clp_nuevo,
            precio_uf_nuevo=precio_uf_nuevo,
            fecha_captura=listing.fecha_captura,
            fecha_cambio=datetime.now(),
        )
    )
    print("price history registrado")


def parse_raw_listings(html):
    if not is_html_processable(html):
        return []

    soup = BeautifulSoup(html, "html.parser")
    content_root = soup.select_one("main") or soup
    cards = find_listing_cards(content_root)
    raw_listings = []
    seen_links = set()

    for card in cards:
        listing = parse_listing_card(card)
        link = listing["link"]

        if not link or link in seen_links:
            continue

        if is_navigation_link(link, listing["titulo"]):
            continue

        seen_links.add(link)
        raw_listings.append(listing)

    return raw_listings


def scroll_page(driver) -> None:
    for scroll_y in (700, 1500, 2600, 3800):
        driver.execute_script("window.scrollTo(0, arguments[0]);", scroll_y)
        time.sleep(1.5)


def wait_for_possible_listings(driver) -> None:
    try:
        wait = WebDriverWait(driver, DEFAULT_WAIT_SECONDS)
        wait.until(
            lambda active_driver: any(
                active_driver.find_elements(By.CSS_SELECTOR, selector)
                for selector in CARD_SELECTORS
            )
        )
    except TimeoutException:
        print("Contenido lento: primer timeout detectando cards. Intentando segundo scroll.")
        scroll_page(driver)
        time.sleep(3)

        try:
            wait = WebDriverWait(driver, DEFAULT_WAIT_SECONDS)
            wait.until(
                lambda active_driver: any(
                    active_driver.find_elements(By.CSS_SELECTOR, selector)
                    for selector in CARD_SELECTORS
                )
            )
            print("Contenido cargado tras segundo intento.")
        except TimeoutException:
            html = driver.page_source or ""

            if html_contains_price(html):
                print("Contenido cargado pero no detectado como cards. Se intentara fallback por precios.")
            else:
                print("Timeout real: no se detectaron cards ni precios en el HTML.")


def find_listing_cards(content_root):
    cards = []

    for selector in CARD_SELECTORS:
        for candidate in content_root.select(selector):
            text = clean_text(candidate.get_text(" ", strip=True))

            if not extract_price(text):
                continue

            if not candidate.find("a", href=True):
                continue

            cards.append(candidate)

    if cards:
        return cards

    # Fallback acotado: solo anchors dentro del contenido principal con precio visible.
    return [
        link
        for link in content_root.select("a[href]")
        if extract_price(clean_text(link.get_text(" ", strip=True)))
        and not is_navigation_link(
            urljoin(BASE_URL, link.get("href", "")),
            link.get_text(" ", strip=True),
        )
    ]


def is_html_processable(html) -> bool:
    if not html:
        print("HTML vacio: no se procesara.")
        return False

    if len(html.strip()) < MIN_HTML_LENGTH:
        print("HTML demasiado corto: posible error de red o bloqueo.")
        return False

    normalized_text = normalize_text(BeautifulSoup(html, "html.parser").get_text(" ", strip=True))
    blocking_texts = [
        "sin resultados",
        "no se encontraron resultados",
        "no encontramos resultados",
        "error",
        "err_internet_disconnected",
        "site cannot be reached",
        "no internet",
    ]

    if any(text in normalized_text for text in blocking_texts):
        print("HTML indica sin resultados o error: no se procesara.")
        return False

    return True


def html_contains_price(html) -> bool:
    return extract_price(BeautifulSoup(html or "", "html.parser").get_text(" ", strip=True)) is not None


def parse_listing_card(card):
    text = clean_text(card.get_text(" ", strip=True))

    return {
        "titulo": extract_title(card, text),
        "precio": extract_price(text),
        "link": extract_link(card),
        "raw_text": text,
    }


def extract_link(card) -> Optional[str]:
    links = card.find_all("a", href=True)

    if getattr(card, "name", None) == "a":
        links = [card]

    for link in links:
        href = link.get("href")

        if not href:
            continue

        absolute_url = urljoin(BASE_URL, href)
        title = clean_text(link.get_text(" ", strip=True))

        if not is_navigation_link(absolute_url, title):
            return normalize_listing_url(absolute_url)

    return None


def normalize_listing_url(url) -> Optional[str]:
    url = clean_text(url)

    if not url:
        return None

    parsed_url = urlparse(url)
    normalized_path = parsed_url.path.rstrip("/") or parsed_url.path

    return urlunparse(
        (
            parsed_url.scheme,
            parsed_url.netloc.lower(),
            normalized_path,
            "",
            "",
            "",
        )
    )


def extract_title(card, text) -> Optional[str]:
    selectors = [
        "h1",
        "h2",
        "h3",
        "[class*='title']",
        "[class*='Title']",
    ]

    for selector in selectors:
        element = card.select_one(selector)
        if element:
            title = clean_text(element.get_text(" ", strip=True))
            if is_valid_title(title):
                return title

    price = extract_price(text)
    if price:
        title = clean_text(text.split(price, 1)[0])
        if is_valid_title(title):
            return title

    return None


def extract_price(text) -> Optional[str]:
    match = re.search(r"(UF\s*[\d.,]+|\$\s*[\d.,]+)", text, flags=re.IGNORECASE)
    return clean_text(match.group(1)) if match else None


def normalize_price(price_text):
    if not price_text:
        return None

    normalized_text = normalize_text(price_text)

    if "uf" in normalized_text:
        amount = parse_uf_amount(price_text)

        if amount is None:
            return None

        return {
            "precio_clp": None,
            "precio_uf": amount,
        }

    if "$" in price_text:
        amount = parse_clp_amount(price_text)

        if amount is None:
            return None

        return {
            "precio_clp": amount,
            "precio_uf": None,
        }

    return None


def parse_uf_amount(value):
    amount_text = re.sub(r"(?i)uf", "", value or "")
    amount_text = re.sub(r"[^\d.,]", "", amount_text)

    if not amount_text:
        return None

    amount_text = amount_text.replace(".", "").replace(",", ".")

    try:
        return float(amount_text)
    except ValueError:
        return None


def parse_clp_amount(value):
    digits = re.sub(r"[^\d]", "", value or "")

    if not digits:
        return None

    return int(digits)


def extract_comuna(text):
    known_comunas = [
        "Nunoa",
        "Ñuñoa",
        "Providencia",
        "Santiago",
        "Las Condes",
        "La Reina",
        "Macul",
        "Vitacura",
        "La Florida",
        "San Miguel",
        "Recoleta",
        "Independencia",
        "Penalolen",
        "Peñalolén",
    ]
    normalized_text = normalize_text(text)

    for comuna in known_comunas:
        if normalize_text(comuna) in normalized_text:
            return display_comuna_name(comuna)

    return None


def display_comuna_name(comuna):
    aliases = {
        "nunoa": "Ñuñoa",
        "penalolen": "Peñalolén",
    }
    return aliases.get(normalize_text(comuna), comuna)


def extract_number_near_keywords(text, keywords):
    normalized_text = normalize_text(text)

    for keyword in keywords:
        normalized_keyword = normalize_text(keyword)
        patterns = [
            rf"(\d+)\s*{re.escape(normalized_keyword)}",
            rf"{re.escape(normalized_keyword)}\s*(\d+)",
        ]

        for pattern in patterns:
            match = re.search(pattern, normalized_text)
            if match:
                return int(match.group(1))

    return None


def extract_m2_from_text(text):
    match = re.search(r"(\d+(?:[.,]\d+)?)\s*m(?:2|²|Â²)", text or "", flags=re.IGNORECASE)

    if not match:
        return None

    amount_text = match.group(1).replace(".", "").replace(",", ".")

    try:
        amount = float(amount_text)
    except ValueError:
        return None

    return amount if amount > 0 else None


def extract_source_listing_id(url):
    if not url:
        return None

    path = urlparse(url).path
    numeric_ids = re.findall(r"\d{5,}", path)

    if numeric_ids:
        return numeric_ids[-1]

    slug = clean_text(path.rstrip("/").split("/")[-1])
    return slug or None


def is_valid_sale_price(normalized_price) -> bool:
    return has_valid_price(
        normalized_price["precio_clp"],
        normalized_price["precio_uf"],
    )


def has_valid_price(precio_clp, precio_uf):
    if precio_uf is not None:
        return precio_uf > 0

    if precio_clp is not None:
        return precio_clp >= MIN_SALE_PRICE_CLP

    return False


def extract_quality_fields(item):
    return {
        "comuna": item.get("comuna"),
        "m2_construidos": item.get("m2_construidos"),
        "dormitorios": item.get("dormitorios"),
        "banos": item.get("banos"),
        "estacionamientos": item.get("estacionamientos"),
    }


def has_quality_signal(
    comuna=None,
    m2_construidos=None,
    dormitorios=None,
    banos=None,
    estacionamientos=None,
):
    return any(
        value is not None
        for value in [
            comuna,
            m2_construidos,
            dormitorios,
            banos,
            estacionamientos,
        ]
    )


def positive_or_none(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None

    if number <= 0:
        return None

    if number.is_integer():
        return int(number)

    return number


def positive_int_or_none(value):
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None

    return number if number > 0 else None


def non_negative_int_or_none(value):
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None

    return number if number >= 0 else None


def float_or_none(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def is_valid_title(title) -> bool:
    normalized_title = normalize_text(title)
    invalid_titles = {
        "venta",
        "arriendo",
        "arriendo de temporada",
        "proyectos nuevos",
        "departamentos",
        "casas",
        "contactar ahora",
        "anadir a favoritos",
        "añadir a favoritos",
        "compara este anuncio",
    }

    if not title or len(title) < 10:
        return False

    return normalized_title not in invalid_titles


def is_navigation_link(link, title) -> bool:
    normalized_link = (link or "").lower()
    normalized_title = normalize_text(title)
    ignored_link_parts = [
        "publicar",
        "ayuda",
        "seguridad",
        "favoritos",
        "login",
        "notificaciones",
        "autos-usados",
        "empleos",
        "marketplace",
        "consejos",
        "centro-de-ayuda",
    ]
    ignored_titles = {
        "venta",
        "arriendo",
        "arriendo de temporada",
        "proyectos nuevos",
        "departamentos",
        "casas",
        "publicar aviso",
    }

    if any(part in normalized_link for part in ignored_link_parts):
        return True

    if normalized_title in ignored_titles:
        return True

    return False


def clean_text(value) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


def normalize_text(value) -> str:
    replacements = {
        "á": "a",
        "é": "e",
        "í": "i",
        "ó": "o",
        "ú": "u",
        "ñ": "n",
        "Ã¡": "a",
        "Ã©": "e",
        "Ã­": "i",
        "Ã³": "o",
        "Ãº": "u",
        "Ã±": "n",
    }
    normalized = (value or "").lower()

    for original, replacement in replacements.items():
        normalized = normalized.replace(original, replacement)

    return normalized


if __name__ == "__main__":
    scrape_and_save(EXAMPLE_URL)
