import argparse
import time

from scraper_yapo import scrape_and_save


ITERACIONES = 6
INTERVALO_SEGUNDOS = 1800
TEST_ITERACIONES = 2
TEST_INTERVALO_SEGUNDOS = 0
URLS = [
    (
        "https://www.yapo.cl/bienes-raices-venta-de-propiedades-apartamentos/"
        "region-metropolitana-nunoa"
    ),
    (
        "https://www.yapo.cl/bienes-raices-venta-de-propiedades-apartamentos/"
        "region-metropolitana-providencia"
    ),
    (
        "https://www.yapo.cl/bienes-raices-venta-de-propiedades-apartamentos/"
        "region-metropolitana-las-condes"
    ),
    (
        "https://www.yapo.cl/bienes-raices-venta-de-propiedades-apartamentos/"
        "region-metropolitana-santiago"
    ),
]


def run_scraper(iteraciones=ITERACIONES, intervalo_segundos=INTERVALO_SEGUNDOS, test_mode=False):
    for iteracion in range(1, iteraciones + 1):
        print("==============================")
        print(f"Iteración {iteracion}/{iteraciones}")

        total_guardados_iteracion = 0

        for url in URLS:
            print(f"Scrapeando: {url}")

            try:
                guardados = scrape_and_save(url)
            except Exception as error:
                print(f"Error scrapeando {url}: {error}")
                continue

            total_guardados_iteracion += guardados or 0

        print(f"Total guardados en esta iteración: {total_guardados_iteracion}")

        if iteracion < iteraciones and intervalo_segundos > 0:
            print("Esperando 30 minutos...")
            time.sleep(intervalo_segundos)

    if test_mode:
        print("TEST FINALIZADO")
    else:
        print("Scraper finalizado correctamente")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Runner controlado para poblar la base con listings de Yapo."
    )
    parser.add_argument(
        "--test",
        action="store_true",
        help="Ejecuta 2 iteraciones seguidas sin espera para validar deduplicación.",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    if args.test:
        run_scraper(
            iteraciones=TEST_ITERACIONES,
            intervalo_segundos=TEST_INTERVALO_SEGUNDOS,
            test_mode=True,
        )
    else:
        run_scraper()
