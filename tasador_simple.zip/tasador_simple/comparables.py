from math import asin, cos, radians, sin, sqrt
from statistics import median

from sqlalchemy import select

from models import Listing


UF_TO_CLP = 37_000
TOP_COMPARABLES = 10
MAX_DISTANCE_KM = 3


def buscar_comparables(
    db,
    comuna,
    m2_construidos,
    dormitorios,
    banos,
    estacionamientos,
):
    min_m2_construidos = m2_construidos * 0.8
    max_m2_construidos = m2_construidos * 1.2
    filters = [
        Listing.comuna == comuna,
        Listing.m2_construidos >= min_m2_construidos,
        Listing.m2_construidos <= max_m2_construidos,
    ]

    if dormitorios is not None:
        filters.extend(
            [
                Listing.dormitorios >= dormitorios - 1,
                Listing.dormitorios <= dormitorios + 1,
            ]
        )

    if banos is not None:
        filters.extend(
            [
                Listing.banos >= banos - 1,
                Listing.banos <= banos + 1,
            ]
        )

    if estacionamientos is not None:
        filters.extend(
            [
                Listing.estacionamientos >= estacionamientos - 1,
                Listing.estacionamientos <= estacionamientos + 1,
            ]
        )

    statement = select(Listing).where(*filters).limit(20)

    return list(db.execute(statement).scalars().all())


def calcular_score_variable(valor_objetivo, valor_comparable):
    if valor_objetivo is None or valor_comparable is None:
        return 0

    if valor_objetivo <= 0:
        return 0

    diferencia = abs(valor_objetivo - valor_comparable)
    return max(1 - (diferencia / valor_objetivo), 0)


def calcular_distancia_km(lat1, lon1, lat2, lon2):
    if None in (lat1, lon1, lat2, lon2):
        return None

    radio_tierra_km = 6371
    delta_lat = radians(lat2 - lat1)
    delta_lon = radians(lon2 - lon1)
    lat1_rad = radians(lat1)
    lat2_rad = radians(lat2)

    haversine = (
        sin(delta_lat / 2) ** 2
        + cos(lat1_rad) * cos(lat2_rad) * sin(delta_lon / 2) ** 2
    )
    distancia = 2 * asin(sqrt(haversine))
    return radio_tierra_km * distancia


def calcular_score_distancia(distancia_km, max_distance_km=MAX_DISTANCE_KM):
    if distancia_km is None:
        return 0

    if distancia_km < 0:
        return 0

    return max(1 - (distancia_km / max_distance_km), 0)


def obtener_precio_clp(listing):
    if listing.precio_clp is not None and listing.precio_clp > 0:
        return listing.precio_clp

    if listing.precio_uf is not None and listing.precio_uf > 0:
        return listing.precio_uf * UF_TO_CLP

    return None


def calcular_percentil(valores, percentil):
    if not valores:
        return None

    valores_ordenados = sorted(valores)
    posicion = (len(valores_ordenados) - 1) * percentil
    indice_inferior = int(posicion)
    indice_superior = min(indice_inferior + 1, len(valores_ordenados) - 1)
    peso_superior = posicion - indice_inferior
    peso_inferior = 1 - peso_superior

    return (
        valores_ordenados[indice_inferior] * peso_inferior
        + valores_ordenados[indice_superior] * peso_superior
    )


def filtrar_outliers_iqr(comparables_validos):
    if len(comparables_validos) < 3:
        return comparables_validos

    precios_m2 = [comparable["precio_m2"] for comparable in comparables_validos]
    p25 = calcular_percentil(precios_m2, 0.25)
    p75 = calcular_percentil(precios_m2, 0.75)

    if p25 is None or p75 is None:
        return comparables_validos

    iqr = p75 - p25
    limite_minimo = p25 - 1.5 * iqr
    limite_maximo = p75 + 1.5 * iqr

    comparables_filtrados = [
        comparable
        for comparable in comparables_validos
        if limite_minimo <= comparable["precio_m2"] <= limite_maximo
    ]

    if len(comparables_filtrados) < 3:
        return comparables_validos

    return comparables_filtrados


def calcular_score_comparable(
    comparable,
    m2_construidos,
    dormitorios,
    banos,
    estacionamientos,
    lat=None,
    lon=None,
):
    score_m2 = calcular_score_variable(m2_construidos, comparable.m2_construidos)
    score_dormitorios = calcular_score_variable(dormitorios, comparable.dormitorios)
    score_banos = calcular_score_variable(banos, comparable.banos)
    score_estacionamientos = calcular_score_variable(
        estacionamientos,
        comparable.estacionamientos,
    )
    distancia_km = calcular_distancia_km(lat, lon, comparable.lat, comparable.lon)
    score_distancia = calcular_score_distancia(distancia_km)

    score = (
        score_m2 * 0.3
        + score_dormitorios * 0.15
        + score_banos * 0.15
        + score_estacionamientos * 0.1
        + score_distancia * 0.3
    )

    return score, distancia_km


def preparar_comparable_valido(
    comparable,
    m2_construidos,
    dormitorios,
    banos,
    estacionamientos,
    lat=None,
    lon=None,
):
    comparable_m2 = comparable.m2_construidos
    precio_clp = obtener_precio_clp(comparable)

    if not comparable_m2 or comparable_m2 <= 0:
        return None

    if precio_clp is None:
        return None

    score, distancia_km = calcular_score_comparable(
        comparable,
        m2_construidos,
        dormitorios,
        banos,
        estacionamientos,
        lat,
        lon,
    )

    if distancia_km is not None and distancia_km > MAX_DISTANCE_KM:
        return None

    if score <= 0:
        return None

    return {
        "listing": comparable,
        "precio_m2": precio_clp / comparable_m2,
        "score": score,
        "distancia_km": distancia_km,
    }


def seleccionar_comparables_mas_relevantes(
    comparables_validos,
    top_n=TOP_COMPARABLES,
):
    comparables_ordenados = sorted(
        comparables_validos,
        key=lambda comparable: comparable["score"],
        reverse=True,
    )

    if len(comparables_ordenados) <= top_n:
        return comparables_ordenados

    return comparables_ordenados[:top_n]


def calcular_score_promedio(comparables_validos):
    if not comparables_validos:
        return 0

    return sum(comparable["score"] for comparable in comparables_validos) / len(
        comparables_validos
    )


def calcular_tasacion_comparables(db, property_data):
    m2_construidos = property_data.get("m2_construidos")
    dormitorios = property_data.get("dormitorios")
    banos = property_data.get("banos")
    estacionamientos = property_data.get("estacionamientos")
    lat = property_data.get("lat")
    lon = property_data.get("lon")

    if not m2_construidos or m2_construidos <= 0:
        return None

    comparables = buscar_comparables(
        db,
        property_data.get("comuna"),
        m2_construidos,
        dormitorios,
        banos,
        estacionamientos,
    )
    print(f"Comparables encontrados: {len(comparables)}")

    if not comparables:
        return None

    comparables_validos = []

    for comparable in comparables:
        comparable_valido = preparar_comparable_valido(
            comparable,
            m2_construidos,
            dormitorios,
            banos,
            estacionamientos,
            lat,
            lon,
        )

        if comparable_valido is not None:
            comparables_validos.append(comparable_valido)

    if not comparables_validos:
        return None

    comparables_relevantes = seleccionar_comparables_mas_relevantes(comparables_validos)
    print(f"Comparables usados: {len(comparables_relevantes)}")
    print(f"Score promedio: {calcular_score_promedio(comparables_relevantes):.3f}")

    comparables_filtrados = filtrar_outliers_iqr(comparables_relevantes)
    precios_m2 = [comparable["precio_m2"] for comparable in comparables_filtrados]

    if not precios_m2:
        return None

    precio_m2_mediana = median(precios_m2)
    return precio_m2_mediana * m2_construidos
