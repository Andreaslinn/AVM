from datetime import date


def calcular_tasacion(
    comuna,
    m2_construidos,
    m2_terreno,
    dormitorios,
    banos,
    estacionamientos,
    piscina,
    ano_construccion,
):
    antiguedad = date.today().year - ano_construccion

    valor_ubicacion = {
        "Vitacura": 20000000,
        "Ñuñoa": 15000000,
        "Puente Alto": 10000000,
    }.get(comuna, 12000000)

    valor_superficie = m2_construidos * 650000 + m2_terreno * 120000
    valor_extras = dormitorios * 3000000 + banos * 2500000 + estacionamientos * 2000000
    if piscina:
        valor_extras += 10000000

    descuento = antiguedad * 500000

    return valor_ubicacion + valor_superficie + valor_extras - descuento
